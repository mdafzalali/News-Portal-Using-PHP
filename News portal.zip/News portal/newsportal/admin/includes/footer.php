
                <footer class="footer text-right">
                   Developed by Md Afzal Ali and Mobassir Mokhtar. © <?php echo date('Y');?>
                </footer>